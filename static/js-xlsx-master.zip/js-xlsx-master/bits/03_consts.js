var DENSE = null;
var DIF_XL = true;
